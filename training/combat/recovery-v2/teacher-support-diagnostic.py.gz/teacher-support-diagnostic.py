import json, numpy as np, torch, onnxruntime as ort
import mjlab.tasks
from mjlab.envs import ManagerBasedRlEnv
from mjlab.tasks.registry import load_env_cfg
from mjlab_microduck.tasks import mdp
cfg=load_env_cfg('Mjlab-DuckFu-Recovery-MicroDuck-v1'); cfg.scene.num_envs=64
cfg.observations['actor'].enable_corruption=False
cfg.seed=1031
env=ManagerBasedRlEnv(cfg,device='cuda:0'); obs,_=env.reset()
opts=ort.SessionOptions(); opts.intra_op_num_threads=1
s=ort.InferenceSession('/tmp/duckfu-frozen-assets/microduck/policies/alpha_stand.onnx',sess_options=opts,providers=['CPUExecutionProvider'])
rows=[]; completed=torch.zeros(64,device='cuda:0',dtype=torch.bool)
for k in range(195):
 x=obs['actor'].cpu().numpy(); u=np.concatenate([s.run(None,{s.get_inputs()[0].name:v[None]})[0] for v in x])
 obs,r,terminated,truncated,info=env.step(torch.from_numpy(u).to('cuda:0'))
 completed|=env._df_recovery_paid
 if k%25==0:
  up,height,speed,support=mdp._duckfu_recovery_state(env)
  rows.append(dict(k=k,up=float(up.mean()),height=float(height.mean()),speed=float(speed.mean()),supported=int(support.sum()),completed=int(completed.sum()),standing=float(mdp.duckfu_recovery_standing(env).mean()),feet_force_max=float(env.scene.sensors['feet_ground_contact'].data.force.abs().max())))
print(json.dumps(rows,indent=2)); env.close()
