"""Renderer-only industrial set dressing. No collision or state changes."""
import numpy as np
import mujoco


def line(scene,a,b,color=(1.,.42,.08,1.),width=2.):
    if scene.ngeom >= scene.maxgeom:return
    g=scene.geoms[scene.ngeom]
    mujoco.mjv_initGeom(g,mujoco.mjtGeom.mjGEOM_LINE,np.zeros(3),np.zeros(3),np.eye(3).ravel(),np.array(color))
    mujoco.mjv_connector(g,mujoco.mjtGeom.mjGEOM_LINE,width,np.asarray(a),np.asarray(b))
    g.emission=.65;g.category=int(mujoco.mjtCatBit.mjCAT_DECOR);scene.ngeom+=1


def box(scene,pos,size,color):
    if scene.ngeom >= scene.maxgeom:return
    g=scene.geoms[scene.ngeom]
    mujoco.mjv_initGeom(g,mujoco.mjtGeom.mjGEOM_BOX,np.asarray(size),np.asarray(pos),np.eye(3).ravel(),np.asarray(color))
    g.category=int(mujoco.mjtCatBit.mjCAT_DECOR);scene.ngeom+=1


def industrial(scene,m,d,report,camera):
    # Only the far side is dressed with tall scenery, keeping every physical
    # obstacle visible from the active camera. Heights are deterministic art.
    far_side=-1 if camera[1]>0 else 1
    for i,x in enumerate(np.arange(-2.8,7.,.65)):
        y=far_side*(.85+.12*(i%3));h=.35+.12*(i%4)
        box(scene,[x,y,h/2],[.10,.10,h/2],[.055,.085,.13,1.])
        line(scene,[x-.10,y-.105,.10],[x-.10,y-.105,h-.04],(.1,.55,.75,1.),2.)
        for z in np.arange(.12,h,.12):
            line(scene,[x-.075,y-.105,z],[x+.075,y-.105,z],(.15,.35,.46,1.),1.)
    # Floor panels and edges stop at the true void; decorative lines never
    # cover the gap. White ticks help viewers perceive actual forward speed.
    width=report['track']['width']
    for g in range(m.ngeom):
        if not m.geom(g).name.startswith('floor/'):continue
        x,y,z=d.geom_xpos[g];sx,sy,sz=m.geom_size[g]
        for xx in np.arange(x-sx+.06,x+sx,.20):
            for side in (-1,1):
                line(scene,[xx,side*(min(sy,width/2)-.018),z+sz+.0006],
                     [xx+.05,side*(min(sy,width/2)-.018),z+sz+.0006],(.55,.65,.68,1.),1.)
    for near,far in report['level']['gaps']:
        for x,sign in [(near,-1),(far,1)]:
            for y in np.arange(-width/2+.01,width/2-.035,.045):
                line(scene,[x+sign*.012,y,.001],[x+sign*.05,y+.028,.001],(1.,.6,.05,1.),3.)
    # The crate silhouette is exactly its physical 13 cm box. Lines are thin
    # cosmetic edges, attached to its measured rigid-body transform.
    center=d.body('crate').xpos;R=d.body('crate').xmat.reshape(3,3)
    for axis in range(3):
        others=[i for i in range(3) if i!=axis]
        for a in (-1,1):
            for b in (-1,1):
                u=np.zeros(3);v=np.zeros(3)
                u[axis]=-.0652;v[axis]=.0652
                u[others]=v[others]=[a*.0652,b*.0652]
                line(scene,center+R@u,center+R@v,(1.,.48,.04,1.),2.)
