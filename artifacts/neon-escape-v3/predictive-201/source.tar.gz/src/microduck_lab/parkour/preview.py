"""Short-horizon model-based skill preview from the current simulation state.

This is privileged-state simulation planning, not vision or Jev inference.
Only cloned data are advanced. The live robot is never reset to a prediction.
Predictions are advisory; full-rate contact/replay gates remain independent.
"""

import copy
import time
import numpy as np
import mujoco
from .jump import CandidateJump, GapAudit
from .world import foot_support
from .skills import lane_command


def preview_jump(m, d, r, far_edge, horizon=2.2, prepare_s=0.0, forward_speed=0.45, brake_s=0.0, settle_s=0.0):
    started = time.perf_counter()
    predicted = copy.copy(d)
    runtime = copy.copy(r)
    runtime.data = predicted
    runtime.bank = copy.copy(r.bank)
    for name in ('last_action', 'command', '_jv_prev', 'default_pose'):
        setattr(runtime, name, getattr(r, name).copy())
    runtime.bank.mirror_run = False
    for _ in range(round(prepare_s / .02)):
        runtime.active_policy = "run"
        runtime.command[:3] = lane_command(runtime, 0.0, forward_speed)
        runtime.step()
        mujoco.mj_step(m, predicted, 100)
    for policy, seconds in [("run", brake_s), ("stand", settle_s)]:
        for _ in range(round(seconds / .02)):
            runtime.active_policy = policy
            runtime.set_command()
            if policy == "run":
                runtime.command[2] = np.clip(-4 * runtime.trunk_yaw(), -2.5, 2.5)
            runtime.step()
            mujoco.mj_step(m, predicted, 100)
    launch_position = runtime.trunk_pos().copy()
    jump = CandidateJump(float(predicted.time), far_edge, landing_tolerance=.19)
    audit = GapAudit()
    audit.sample(m, predicted, runtime)
    min_up = 1.0
    max_side = abs(float(runtime.trunk_pos()[1]))
    for _ in range(round(horizon / .02)):
        jump.update(m, predicted, runtime, audit)
        runtime.step()
        # Known currently applied machinery forces are held over this short
        # gap-local forecast. No future hazard event or seed is inspected.
        mujoco.mj_step(m, predicted, 100)
        audit.sample(m, predicted, runtime)
        min_up = min(min_up, float(predicted.xmat[r.trunk_body_id, 8]))
        max_side = max(max_side, abs(float(runtime.trunk_pos()[1])))
        if jump.status != 'RUNNING' or runtime.trunk_pos()[2] < -0.10:
            break
    passed = bool(
        jump.status == 'SUCCESS'
        and runtime.trunk_pos()[0] > far_edge + .015
        and runtime.trunk_pos()[2] > .10
        and min_up > .80
        and max_side < .20
        and foot_support(m, predicted, 'floor/1')
    )
    return dict(passed=passed, prepare_s=prepare_s, forward_speed=forward_speed, brake_s=brake_s, settle_s=settle_s, launch_position=launch_position.tolist(), status=jump.status, min_upright=min_up,
                max_abs_y_m=max_side, final_position=runtime.trunk_pos().tolist(),
                predicted_duration_s=float(predicted.time-d.time),
                wall_ms=1000*(time.perf_counter()-started))

class GapSequence:
    """Execute the same motor-only approach evaluated in the preview."""
    name = 'JUMP_CENTER'
    status = 'RUNNING'

    def __init__(self, started, far_edge, plan, position):
        self.started = started
        self.far_edge = far_edge
        self.plan = plan
        self.launch_position = position.copy()
        self.tick = 0
        self.jump = None
        self.events = []
        self.phase = 'APPROACH'

    def update(self, m, d, r, audit):
        advance = round(self.plan['prepare_s'] / .02)
        brake = round(self.plan['brake_s'] / .02)
        settle = round(self.plan['settle_s'] / .02)
        r.bank.mirror_run = False
        if self.tick < advance + brake + settle:
            r.joint_vel_delay = 0
            r.set_command()
            if self.tick < advance:
                self.phase = 'APPROACH'
                r.active_policy = 'run'
                r.command[:3] = lane_command(r, 0.0, self.plan['forward_speed'])
            elif self.tick < advance + brake:
                self.phase = 'BRAKE'
                r.active_policy = 'run'
                r.command[2] = np.clip(-4 * r.trunk_yaw(), -2.5, 2.5)
            else:
                self.phase = 'SETTLE'
                r.active_policy = 'stand'
            self.tick += 1
            return self.status
        if self.jump is None:
            self.jump = CandidateJump(float(d.time), self.far_edge, landing_tolerance=.19)
            self.events.append(dict(type='SKILL_START', skill=self.name, t=float(d.time)))
        self.status = self.jump.update(m, d, r, audit)
        self.phase = self.jump.phase
        if self.status != 'RUNNING':
            self.events.extend(self.jump.events)
        return self.status


def choose_gap_sequence(m, d, r, far_edge):
    """Bounded candidate set; stop at first acceptable physical prediction."""
    trials = []
    for advance, brake, settle in [(.16,.4,.2),(.08,.4,.2),(.24,.4,.2),(.08,.2,.5),(.24,.4,.5),(0.,.6,.2)]:
        result = preview_jump(m,d,r,far_edge,prepare_s=advance,
                              forward_speed=.45,brake_s=brake,settle_s=settle)
        trials.append(result)
        if result['passed']:
            return result, trials
    return None, trials
