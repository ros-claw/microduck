"""Contact-causal bowling lock and verified encounter combos.

No geometry, root pose or prop velocity is written by this ledger. The driver
opens the force-limited exit only after the recorded contact chain qualifies.
"""
from dataclasses import dataclass, field
import mujoco
import numpy as np


@dataclass
class BowlingLock:
    pins: tuple = ('pin0', 'pin1', 'pin2')
    events: list = field(default_factory=list)
    impulse: dict = field(default_factory=dict)
    struck: set = field(default_factory=set)
    toppled: set = field(default_factory=set)
    contaminated: set = field(default_factory=set)
    duck_push_impulse: float = 0.0
    max_push_force: float = 0.0
    unlocked: bool = False
    push_started: bool = False

    def sample(self, m, d):
        force = np.zeros(6)
        for i,c in enumerate(d.contact):
            names = [m.body(m.geom_bodyid[g]).name for g in (c.geom1,c.geom2)]
            if 'playball' not in names and not any(n in self.pins for n in names):
                continue
            mujoco.mj_contactForce(m,d,i,force)
            if force[0] <= 1e-7:
                continue
            if 'playball' in names and any(n.startswith('duck/') for n in names):
                self.duck_push_impulse += float(force[0])*m.opt.timestep
                self.max_push_force = max(self.max_push_force,float(force[0]))
                if not self.push_started:
                    self.push_started = True
                    self.events.append(dict(type='BALL_PUSH',t=float(d.time)))
            for pin in self.pins:
                if pin not in names:
                    continue
                other = names[1] if names[0] == pin else names[0]
                if other.startswith('duck/') or other == 'boss':
                    self.contaminated.add(pin)
                if other == 'playball' and self.duck_push_impulse > .001:
                    self.impulse[pin] = self.impulse.get(pin,0.0)+float(force[0])*m.opt.timestep
                    if self.impulse[pin] > .0005:
                        self.struck.add(pin)
        for pin in self.pins:
            if (pin in self.struck and pin not in self.toppled
                    and pin not in self.contaminated and d.body(pin).xmat[8] < .35):
                self.toppled.add(pin)
                self.events.append(dict(type='PIN_DOWN',t=float(d.time),pin=pin,
                                        ball_impulse_Ns=self.impulse[pin]))
        if not self.unlocked and len(self.toppled) == len(self.pins):
            self.unlocked = True
            self.events.append(dict(type='BOWLING_STRIKE',t=float(d.time),pins=list(self.pins),
                                    duck_push_impulse_Ns=self.duck_push_impulse))
            self.events.append(dict(type='EXIT_UNLOCK',t=float(d.time),cause='duck → ball → three pins'))

    def report(self):
        return dict(unlocked=self.unlocked,ball_hit_pins=sorted(self.struck),
                    qualified_toppled=sorted(self.toppled),direct_or_boss_hit_pins=sorted(self.contaminated),
                    duck_push_impulse_Ns=self.duck_push_impulse,max_push_force_N=self.max_push_force,
                    ball_pin_impulses_Ns=self.impulse,
                    rule='Duck-ball impulse > .001 Ns, ball-pin impulse > .0005 Ns per pin, pin up < .35; no prior duck/boss pin hit')


class ArcadeDriver:
    """Wrap existing finite-force machinery; gate stays locked until a strike."""
    def __init__(self, hazards):
        from .hazards import HazardDriver
        self.base = HazardDriver(hazards)
        self.hazards = self.base.hazards
        self.warnings = self.base.warnings
        self.released = self.base.released
        self.events = self.base.events
        self.bowling = BowlingLock()

    def step(self,m,d,duck_x):
        self.base.step(m,d,duck_x)
        portal = next(h for h in self.hazards if h.kind=='finish_gate')
        target = 0.0 if self.bowling.unlocked and duck_x <= portal.x+.25 else -.6
        d.ctrl[m.actuator('portal/motor').id] = target

    def sample(self,m,d):
        self.bowling.sample(m,d)


def bowling_command(r, m, d):
    """Follow the observed ball while behind it, then aim for the exit roll."""
    from .skills import lane_command
    ball = d.body('playball').xpos
    target = float(np.clip(ball[1],-.12,.12)) if r.trunk_pos()[0] < 5.9 else 0.0
    if r.trunk_pos()[0] < 5.15:
        target=0.0
    r.bank.mirror_run = target-r.trunk_pos()[1] < -.025
    return lane_command(r,target,.55)


class EncounterCombo:
    def __init__(self):
        self.events=[]
        self.verified=set()

    def certify(self,name,t,condition,evidence):
        if condition and name not in self.verified:
            self.verified.add(name)
            self.events.append(dict(type='COMBO_VERIFIED',t=float(t),challenge=name,
                                    combo=len(self.verified),evidence=evidence))

    def sample(self,m,d,r,audit,gap,driver,results,level):
        h={x.name:x for x in level.hazards}
        x=float(r.trunk_pos()[0]);upright=bool(d.xmat[r.trunk_body_id,8]>.9)
        success=lambda stage: any(s['stage']==stage and s['status']=='SUCCESS' for s in results)
        self.certify('ROLL UNDER',d.time,success('ROLL') and x>h['bar'].x+.12 and 'bar' not in audit.contacts,
                     'completed >5.7 rad roll with foot support, crossed bar without force contact')
        self.certify('DROP DODGE',d.time,x>h['crate'].x+.22 and upright and 'crate' not in audit.contacts and 'crate' in driver.released,
                     'passed released crate plane upright without force contact')
        self.certify('VOID JUMP',d.time,gap.crossed and success('JUMP'),
                     'full-rate airborne gap crossing and force-bearing landing')
        self.certify('SWEEPER PASS',d.time,x>h['sweeper'].x+.4 and upright and 'sweeper' not in audit.contacts,
                     'passed moving-arm plane upright without force contact')
        self.certify('BOWLING STRIKE',d.time,driver.bowling.unlocked,
                     'duck-ball-pins force chain, all three pins toppled')
        self.certify('EXIT ROLL',d.time,success('EXIT_ROLL') and x>h['exit_bar'].x+.12 and 'exit_bar' not in audit.contacts,
                     'second completed roll with foot support, passed exit bar without force contact')
